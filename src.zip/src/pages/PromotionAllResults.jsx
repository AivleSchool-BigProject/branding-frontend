// src/pages/PromotionAllResults.jsx
import React, { useMemo } from "react";
import { useNavigate } from "react-router-dom";

import SiteHeader from "../components/SiteHeader.jsx";
import SiteFooter from "../components/SiteFooter.jsx";

function safeParse(raw) {
  try {
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

const SERVICES = [
  {
    key: "icon",
    title: "제품 아이콘 컨설팅",
    desc: "아이콘 콘셉트 3안 + 이미지 프롬프트",
    resultKey: "promoInterviewResult_icon_v1",
    draftKey: "promoInterviewDraft_icon_v1",
    interviewRoute: "/promotion/icon/interview",
    resultRoute: "/promotion/result?service=icon",
  },
  {
    key: "aicut",
    title: "AI컷 모델 컨설팅",
    desc: "모델 컷 콘셉트 3안 + 촬영/프롬프트 가이드",
    resultKey: "promoInterviewResult_aicut_v1",
    draftKey: "promoInterviewDraft_aicut_v1",
    interviewRoute: "/promotion/aicut/interview",
    resultRoute: "/promotion/result?service=aicut",
  },
  {
    key: "staging",
    title: "제품 연출컷 컨설팅",
    desc: "연출 장면 3안 + 소품/구도/프롬프트",
    resultKey: "promoInterviewResult_staging_v1",
    draftKey: "promoInterviewDraft_staging_v1",
    interviewRoute: "/promotion/staging/interview",
    resultRoute: "/promotion/result?service=staging",
  },
  {
    key: "poster",
    title: "SNS 제품 포스터 컨설팅",
    desc: "카피/레이아웃 3안 + 포스터 프롬프트",
    resultKey: "promoInterviewResult_poster_v1",
    draftKey: "promoInterviewDraft_poster_v1",
    interviewRoute: "/promotion/poster/interview",
    resultRoute: "/promotion/result?service=poster",
  },
];

export default function PromotionAllResults({ onLogout }) {
  const navigate = useNavigate();

  const cards = useMemo(() => {
    return SERVICES.map((s) => {
      const result = safeParse(localStorage.getItem(s.resultKey));
      const draft = safeParse(localStorage.getItem(s.draftKey));
      const selectedId = result?.selectedId || result?.selected?.id;
      const selected = result?.selected || result?.candidates?.find?.((c) => c.id === selectedId);
      const isDone = Boolean(selectedId);
      const inProgress = !isDone && Boolean(draft?.form);
      const updatedAt = result?.updatedAt || draft?.updatedAt;
      const updatedLabel = updatedAt ? new Date(updatedAt).toLocaleString() : "-";

      return {
        ...s,
        isDone,
        inProgress,
        updatedLabel,
        selectedTitle: selected?.name || "",
      };
    }).sort((a, b) => {
      // 완료 > 진행중 > 미시작
      const score = (x) => (x.isDone ? 2 : x.inProgress ? 1 : 0);
      return score(b) - score(a);
    });
  }, []);

  return (
    <div className="mypage">
      <SiteHeader onLogout={onLogout} />

      <main className="mypage__main">
        <div className="mypage__container">
          <div className="mypage__titleRow">
            <div>
              <h1 className="mypage__title">홍보물 컨설팅 결과 모아보기</h1>
              <p className="mypage__sub">
                4개의 홍보물 컨설팅 서비스 결과를 한 곳에서 확인할 수 있어요.
              </p>
            </div>

            <div className="mypage__actions">
              <button type="button" className="btn ghost" onClick={() => navigate("/promotion")}
              >
                홍보물 컨설팅 홈
              </button>
              <button type="button" className="btn" onClick={() => navigate("/mypage")}
              >
                마이페이지
              </button>
            </div>
          </div>

          <div className="mypage__grid">
            {cards.map((c) => (
              <div key={c.key} className="mypageCard">
                <div className="mypageCard__head">
                  <div>
                    <h3 className="mypageCard__title">{c.title}</h3>
                    <p className="mypageCard__desc">{c.desc}</p>
                  </div>
                  <span className={`statusBadge ${c.isDone ? "done" : c.inProgress ? "progress" : "todo"}`}>
                    {c.isDone ? "완료" : c.inProgress ? "진행중" : "미시작"}
                  </span>
                </div>

                <div className="mypageCard__meta">
                  <div className="row">
                    <span className="k">마지막 저장</span>
                    <span className="v">{c.updatedLabel}</span>
                  </div>
                  {c.isDone && c.selectedTitle ? (
                    <div className="row">
                      <span className="k">선택한 안</span>
                      <span className="v">{c.selectedTitle}</span>
                    </div>
                  ) : null}
                </div>

                <div className="mypageCard__actions">
                  {c.isDone ? (
                    <button type="button" className="btn primary" onClick={() => navigate(c.resultRoute)}>
                      결과 보기
                    </button>
                  ) : (
                    <button type="button" className="btn primary" onClick={() => navigate(c.interviewRoute)}>
                      {c.inProgress ? "인터뷰 이어하기" : "인터뷰 시작"}
                    </button>
                  )}
                  <button type="button" className="btn ghost" onClick={() => navigate(c.interviewRoute)}>
                    설문으로 이동
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
