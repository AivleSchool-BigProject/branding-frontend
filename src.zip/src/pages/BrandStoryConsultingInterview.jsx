// src/pages/BrandStoryConsultingInterview.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

import SiteHeader from "../components/SiteHeader.jsx";
import SiteFooter from "../components/SiteFooter.jsx";

import ConsultingFlowPanel from "../components/ConsultingFlowPanel.jsx";
import ConsultingFlowMini from "../components/ConsultingFlowMini.jsx";

import PolicyModal from "../components/PolicyModal.jsx";
import { PrivacyContent, TermsContent } from "../components/PolicyContents.jsx";

const STORAGE_KEY = "brandStoryConsultingInterviewDraft_v1";
const RESULT_KEY = "brandStoryConsultingInterviewResult_v1";
const LEGACY_KEY = "brandInterview_story_v1";

// ✅ 기타(직접 입력) 값(내부 식별용)
const OTHER_VALUE = "__other__";

// ✅ 산업/타깃 선택지
const INDUSTRY_OPTIONS = [
  "IT/SaaS",
  "AI/데이터",
  "이커머스/쇼핑",
  "마케팅/광고",
  "교육/에듀테크",
  "헬스케어/바이오",
  "핀테크",
  "부동산/프롭테크",
  "여행/레저",
  "미디어/콘텐츠",
  "제조/하드웨어",
  "F&B/프랜차이즈",
  "뷰티/패션",
  "B2B 서비스/컨설팅",
  "공공/지자체",
  "기타(직접 입력)",
];

const TARGET_OPTIONS = [
  "일반 소비자(B2C)",
  "직장인/실무자",
  "대학생/취준생",
  "10대/청소년",
  "부모/가정",
  "시니어",
  "소상공인/자영업자",
  "스타트업 대표/창업팀",
  "중소기업 담당자",
  "대기업 담당자",
  "공공기관 담당자",
  "기타(직접 입력)",
];

function safeText(v, fallback = "") {
  const s = String(v ?? "").trim();
  return s ? s : fallback;
}

function pickKeywords(text, max = 8) {
  const raw = String(text || "")
    .split(/[,\n\t]/g)
    .map((s) => s.trim())
    .filter(Boolean);
  const uniq = Array.from(new Set(raw));
  return uniq.slice(0, max);
}

function generateStoryCandidates(form, seed = 0) {
  const company = safeText(form?.companyName, "브랜드");
  const oneLine = safeText(form?.oneLine, "");
  const core = safeText(form?.brandCore, "핵심 가치");
  const goal = safeText(form?.goal, "소개/피치에 쓸 스토리");
  const tone = safeText(form?.tone, "담백/신뢰");
  const proof = safeText(form?.proof, "");
  const origin = safeText(form?.originStory, "우리는 현장에서 반복되는 비효율을 보았습니다.");
  const problem = safeText(form?.problemStory, "고객은 방향을 잡지 못해 시간과 비용을 낭비합니다.");
  const solution = safeText(form?.solutionStory, "인터뷰 기반 진단 → 전략 추천 → 실행 가이드로 해결합니다.");

  const pick = (arr, idx) => arr[(idx + seed) % arr.length];

  const hooks = [
    "작은 팀도 ‘바로 실행’할 수 있는 전략",
    "복잡한 과정을 ‘한 장’으로 정리하는 힘",
    "시간과 비용을 아끼는 가장 빠른 방법",
    "데이터 기반으로 ‘확신’까지 설계",
  ];
  const hook = pick(hooks, 0);

  const keyMessages = [
    `우리는 ${core}를 통해 ${hook}을 제공합니다.`,
    `고객은 ${problem.replace(/\.$/, "")} — 우리는 이를 ‘실행 가능한 단계’로 바꿉니다.`,
    proof ? `근거: ${proof}` : "근거: 수치/사례를 추가하면 설득력이 더 커집니다.",
  ];

  const candidates = [
    {
      id: "storyA",
      name: "A · 담백한 About(홈페이지/소개용)",
      oneLiner: "짧고 명료하게 ‘왜/무엇/어떻게’를 전달하는 버전",
      tone: tone || "담백/신뢰",
      tagline: `${company} — ${oneLine || "한 줄로 이해되는 브랜드"}`,
      about: [
        `${company}는 ${core}를 중심으로 움직입니다.`,
        `${origin}`,
        `그래서 우리는 ${solution}`,
      ],
      keyMessages,
      useCases: ["홈페이지 About", "서비스 소개 페이지", "회사 소개서 1p"],
    },
    {
      id: "storyB",
      name: "B · 문제-해결 중심(세일즈/제휴용)",
      oneLiner: "고객 문제를 전면에 두고, 해결·차별점을 강조하는 버전",
      tone: "문제 해결 · 실무적",
      tagline: `문제를 해결하는 ${company}`,
      about: [
        `문제: ${problem}`,
        `해결: ${solution}`,
        `차별점: ${core}를 ‘실행 가능한 형태’로 바꿉니다.`,
      ],
      keyMessages: [
        `고객 문제를 정교하게 정의하고, 실행 단계로 쪼갭니다.`,
        `짧은 시간 안에 ‘방향’과 ‘행동’을 함께 제공합니다.`,
        proof ? `성과/증거: ${proof}` : "성과/증거를 한 줄로 추가하면 좋습니다.",
      ],
      useCases: ["세일즈 피치", "제휴 제안서", "B2B 소개"],
    },
    {
      id: "storyC",
      name: "C · 피치덱(투자/발표용)",
      oneLiner: "투자자/심사위원이 좋아하는 구조(Why-Now → Problem → Solution)",
      tone: "임팩트 · 확장",
      tagline: `${company}: ${hook}`,
      about: [
        `Why-now: 시장/고객은 더 빠른 실행을 필요로 합니다.`,
        `Problem: ${problem}`,
        `Solution: ${solution}`,
        proof ? `Proof: ${proof}` : "Proof: 핵심 지표/사례를 추가하세요.",
      ],
      keyMessages: [
        `핵심 가치: ${core}`,
        `목표: ${goal}`,
        `확장성: 다양한 채널/산업으로 적용 가능`,
      ],
      useCases: ["IR 피치덱", "지원사업 발표", "데모데이"],
    },
  ];

  return candidates.slice(0, 3);
}

export default function BrandStoryConsultingInterview({ onLogout }) {
  const navigate = useNavigate();

  // ✅ 약관/방침 모달
  const [openType, setOpenType] = useState(null);
  const closeModal = () => setOpenType(null);

  // ✅ 폼 상태
  const [form, setForm] = useState({
    companyName: "",
    industry: "", // select
    industryOther: "", // ✅ 기타 입력칸
    stage: "",
    website: "",

    oneLine: "",
    targetCustomer: "", // select
    targetCustomerOther: "", // ✅ 기타 입력칸

    brandCore: "",
    originStory: "",
    problemStory: "",
    solutionStory: "",

    tone: "",
    keyMessages: "",
    proof: "",
    goal: "",

    notes: "", // 기타사항(추가 메모)
  });

  // ✅ 저장 상태 UI
  const [saveMsg, setSaveMsg] = useState("");
  const [lastSaved, setLastSaved] = useState("-");
// ✅ 결과(후보/선택) 상태
const [analyzing, setAnalyzing] = useState(false);
const [candidates, setCandidates] = useState([]);
const [selectedId, setSelectedId] = useState(null);
const [regenSeed, setRegenSeed] = useState(0);
const refResult = useRef(null);


  // 섹션 스크롤 ref
  const refBasic = useRef(null);
  const refCore = useRef(null);
  const refStory = useRef(null);
  const refTone = useRef(null);
  const refGoal = useRef(null);

  const sections = useMemo(
    () => [
      { id: "basic", label: "기본 정보", ref: refBasic },
      { id: "core", label: "브랜드 핵심", ref: refCore },
      { id: "story", label: "스토리 구성", ref: refStory },
      { id: "tone", label: "톤/메시지", ref: refTone },
      { id: "goal", label: "목표/근거", ref: refGoal },
    ],
    [],
  );

  // ✅ 필수 항목(최소)
  const requiredKeys = useMemo(
    () => [
      "companyName",
      "industry",
      "stage",
      "oneLine",
      "targetCustomer",
      "brandCore",
      "goal",
    ],
    [],
  );

  const setValue = (key, value) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  // ✅ “필수 완료” 판정(기타 선택 시에는 기타 입력칸도 필수)
  const isRequiredFilled = (key) => {
    if (key === "industry") {
      if (form.industry === OTHER_VALUE)
        return Boolean(form.industryOther.trim());
      return Boolean(form.industry.trim());
    }
    if (key === "targetCustomer") {
      if (form.targetCustomer === OTHER_VALUE)
        return Boolean(form.targetCustomerOther.trim());
      return Boolean(form.targetCustomer.trim());
    }
    return Boolean(String(form[key] || "").trim());
  };

  const requiredStatus = useMemo(() => {
    const status = {};
    requiredKeys.forEach((k) => {
      status[k] = isRequiredFilled(k);
    });
    return status;
  }, [requiredKeys, form]); // eslint-disable-line react-hooks/exhaustive-deps

  const completedRequired = useMemo(
    () => requiredKeys.filter((k) => requiredStatus[k]).length,
    [requiredKeys, requiredStatus],
  );

  const progress = useMemo(() => {
    if (requiredKeys.length === 0) return 0;
    return Math.round((completedRequired / requiredKeys.length) * 100);
  }, [completedRequired, requiredKeys.length]);

  const canAnalyze = completedRequired === requiredKeys.length;
  const hasResult = candidates.length > 0;
  const canGoNext = Boolean(hasResult && selectedId);

  // ✅ 현재 단계(대략)
  const currentSectionLabel = useMemo(() => {
    const basicOk =
      isRequiredFilled("companyName") &&
      isRequiredFilled("industry") &&
      isRequiredFilled("stage");

    if (!basicOk) return "기본 정보";
    if (!isRequiredFilled("brandCore")) return "브랜드 핵심";
    if (!isRequiredFilled("goal")) return "목표/근거";
    return "완료";
  }, [form]); // eslint-disable-line react-hooks/exhaustive-deps

  // ✅ draft 로드
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed?.form) setForm((prev) => ({ ...prev, ...parsed.form }));
      if (parsed?.updatedAt) {
        const d = new Date(parsed.updatedAt);
        if (!Number.isNaN(d.getTime())) setLastSaved(d.toLocaleString());
      }
    } catch {
      // ignore
    }
  }, []);

  // ✅ 결과 로드(후보/선택)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(RESULT_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed?.candidates)) setCandidates(parsed.candidates);
      if (parsed?.selectedId) setSelectedId(parsed.selectedId);
      if (typeof parsed?.regenSeed === "number") setRegenSeed(parsed.regenSeed);
    } catch {
      // ignore
    }
  }, []);

  // ✅ 자동 저장(디바운스)
  useEffect(() => {
    setSaveMsg("");
    const t = setTimeout(() => {
      try {
        const payload = { form, updatedAt: Date.now() };
        localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
        setLastSaved(new Date(payload.updatedAt).toLocaleString());
        setSaveMsg("자동 저장됨");
      } catch {
        // ignore
      }
    }, 600);

    return () => clearTimeout(t);
  }, [form]);

  const handleTempSave = () => {
    try {
      const payload = { form, updatedAt: Date.now() };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
      setLastSaved(new Date(payload.updatedAt).toLocaleString());
      setSaveMsg("임시 저장 완료");
    } catch {
      setSaveMsg("저장 실패");
    }
  };

  const scrollToSection = (ref) => {
    if (!ref?.current) return;
    ref.current.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleNext = () => {
    const map = {
      "기본 정보": refCore,
      "브랜드 핵심": refStory,
      "목표/근거": null,
      완료: null,
    };
    const nextRef = map[currentSectionLabel];
    if (!nextRef) return;
    scrollToSection(nextRef);
  };

  // ✅ 결과 페이지 연결
  const scrollToResult = () => {
    if (!refResult?.current) return;
    refResult.current.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const persistResult = (nextCandidates, nextSelectedId, nextSeed) => {
    const updatedAt = Date.now();
    try {
      localStorage.setItem(
        RESULT_KEY,
        JSON.stringify({
          candidates: nextCandidates,
          selectedId: nextSelectedId,
          regenSeed: nextSeed,
          updatedAt,
        }),
      );
    } catch {
      // ignore
    }

    // ✅ legacy 저장(통합 결과/결과 리포트 페이지 호환)
    try {
      const selected = nextCandidates.find((c) => c.id === nextSelectedId) || null;
      localStorage.setItem(
        LEGACY_KEY,
        JSON.stringify({
          form,
          candidates: nextCandidates,
          selectedId: nextSelectedId,
          selected,
          regenSeed: nextSeed,
          updatedAt,
        }),
      );
    } catch {
      // ignore
    }
  };

  const handleGenerateCandidates = async (mode = "generate") => {
    // 🔌 BACKEND 연동 포인트 (브랜드 스토리 - AI 분석 요청 버튼)
    // - 현재 로직: 프론트에서 더미 후보(3안) 생성 → 1개 선택 → 다음 단계(로고 컨설팅)로 이동
    // - 백엔드 연동 시(명세서 기준):
    //   A) 인터뷰 저장(공통): POST /brands/interview
    //   B) 스토리 생성:      POST /brands/story
    //      → 이후 결과 조회: GET  /brands/story (param: story)
    if (!canAnalyze) {
      alert("필수 항목을 모두 입력하면 요청이 가능합니다.");
      return;
    }

    setAnalyzing(true);
    try {
      const nextSeed = mode === "regen" ? regenSeed + 1 : regenSeed;
      if (mode === "regen") setRegenSeed(nextSeed);

      await new Promise((r) => setTimeout(r, 450));
      const nextCandidates = generateStoryCandidates(form, nextSeed);

      setCandidates(nextCandidates);
      setSelectedId(null);
      persistResult(nextCandidates, null, nextSeed);
      scrollToResult();
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSelectCandidate = (id) => {
    setSelectedId(id);
    persistResult(candidates, id, regenSeed);
  };

  const handleGoNext = () => {
    // ✅ 다음 단계: 로고 컨설팅 인터뷰
    navigate("/logoconsulting");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleResetAll = () => {
    const ok = window.confirm("입력/결과를 모두 초기화할까요?");
    if (!ok) return;

    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(RESULT_KEY);
      localStorage.removeItem(LEGACY_KEY);
    } catch {
      // ignore
    }

    setForm({
      companyName: "",
      industry: "",
      industryOther: "",
      stage: "",
      website: "",
      oneLine: "",
      targetCustomer: "",
      targetCustomerOther: "",
      brandCore: "",
      originStory: "",
      problemStory: "",
      solutionStory: "",
      tone: "",
      keyMessages: "",
      proof: "",
      goal: "",
      notes: "",
    });

    setCandidates([]);
    setSelectedId(null);
    setRegenSeed(0);
    setSaveMsg("");
    setLastSaved("-");
  };

  // ✅ select 변경 시 기타 입력칸 처리
  const handleIndustryChange = (v) => {
    if (v === OTHER_VALUE) {
      setForm((prev) => ({ ...prev, industry: OTHER_VALUE }));
      return;
    }
    setForm((prev) => ({ ...prev, industry: v, industryOther: "" }));
  };

  const handleTargetChange = (v) => {
    if (v === OTHER_VALUE) {
      setForm((prev) => ({ ...prev, targetCustomer: OTHER_VALUE }));
      return;
    }
    setForm((prev) => ({
      ...prev,
      targetCustomer: v,
      targetCustomerOther: "",
    }));
  };

  return (
    <div className="diagInterview consultingInterview">
      <PolicyModal
        open={openType === "privacy"}
        title="개인정보 처리방침"
        onClose={closeModal}
      >
        <PrivacyContent />
      </PolicyModal>

      <PolicyModal
        open={openType === "terms"}
        title="이용약관"
        onClose={closeModal}
      >
        <TermsContent />
      </PolicyModal>

      <SiteHeader onLogout={onLogout} />

      <main className="diagInterview__main">
        <div className="diagInterview__container">
          <div className="diagInterview__titleRow">
            <div>
              <h1 className="diagInterview__title">
                브랜드 스토리 컨설팅 인터뷰
              </h1>
              <p className="diagInterview__sub">
                브랜드가 왜 시작됐고, 무엇을 해결하며, 어떤 방향으로 가는지
                “이야기”로 정리합니다.
              </p>
            </div>

            <div className="diagInterview__topActions">
              <button
                type="button"
                className="btn ghost"
                onClick={() => navigate("/brandconsulting")}
              >
                브랜드 컨설팅으로
              </button>
              <button type="button" className="btn" onClick={handleTempSave}>
                임시저장
              </button>
            </div>
          </div>

          {/* ✅ 전체 4단계 진행 표시 */}
          <ConsultingFlowPanel activeKey="story" />

          <div className="diagInterview__grid">
            <section className="diagInterview__left">
              {/* 1) BASIC */}
              <div className="card" ref={refBasic}>
                <div className="card__head">
                  <h2>1. 기본 정보</h2>
                  <p>기본 정보는 스토리의 전제(맥락)가 됩니다.</p>
                </div>

                <div className="formGrid">
                  <div className="field">
                    <label>
                      회사/프로젝트명 <span className="req">*</span>
                    </label>
                    <input
                      value={form.companyName}
                      onChange={(e) => setValue("companyName", e.target.value)}
                      placeholder="예) BRANDPILOT"
                    />
                  </div>

                  {/* ✅ 산업/분야: select + 기타 입력 */}
                  <div className="field">
                    <label>
                      산업/분야 <span className="req">*</span>
                    </label>
                    <select
                      value={
                        form.industry === OTHER_VALUE
                          ? OTHER_VALUE
                          : form.industry
                      }
                      onChange={(e) => {
                        const v = e.target.value;
                        if (v === "기타(직접 입력)")
                          handleIndustryChange(OTHER_VALUE);
                        else handleIndustryChange(v);
                      }}
                    >
                      <option value="">선택</option>
                      {INDUSTRY_OPTIONS.map((opt) => (
                        <option
                          key={opt}
                          value={
                            opt === "기타(직접 입력)" ? "기타(직접 입력)" : opt
                          }
                        >
                          {opt}
                        </option>
                      ))}
                    </select>

                    {form.industry === OTHER_VALUE ? (
                      <div style={{ marginTop: 10 }}>
                        <input
                          value={form.industryOther}
                          onChange={(e) =>
                            setValue("industryOther", e.target.value)
                          }
                          placeholder="산업/분야를 직접 입력하세요 (예: 반려동물/펫테크)"
                        />
                      </div>
                    ) : null}
                  </div>

                  <div className="field">
                    <label>
                      성장 단계 <span className="req">*</span>
                    </label>
                    <select
                      value={form.stage}
                      onChange={(e) => setValue("stage", e.target.value)}
                    >
                      <option value="">선택</option>
                      <option value="idea">아이디어 단계</option>
                      <option value="mvp">MVP/테스트 중</option>
                      <option value="pmf">PMF 탐색</option>
                      <option value="revenue">매출 발생</option>
                      <option value="invest">투자 유치 진행</option>
                    </select>
                  </div>

                  <div className="field">
                    <label>웹사이트/소개 링크 (선택)</label>
                    <input
                      value={form.website}
                      onChange={(e) => setValue("website", e.target.value)}
                      placeholder="예) https://..."
                    />
                  </div>
                </div>

                <div className="field">
                  <label>
                    한 줄 소개 <span className="req">*</span>
                  </label>
                  <input
                    value={form.oneLine}
                    onChange={(e) => setValue("oneLine", e.target.value)}
                    placeholder="예) 초기 스타트업을 위한 AI 브랜딩 컨설팅 플랫폼"
                  />
                </div>

                {/* ✅ 타깃 고객: select + 기타 입력 */}
                <div className="field">
                  <label>
                    타깃 고객 <span className="req">*</span>
                  </label>
                  <select
                    value={
                      form.targetCustomer === OTHER_VALUE
                        ? OTHER_VALUE
                        : form.targetCustomer
                    }
                    onChange={(e) => {
                      const v = e.target.value;
                      if (v === "기타(직접 입력)")
                        handleTargetChange(OTHER_VALUE);
                      else handleTargetChange(v);
                    }}
                  >
                    <option value="">선택</option>
                    {TARGET_OPTIONS.map((opt) => (
                      <option
                        key={opt}
                        value={
                          opt === "기타(직접 입력)" ? "기타(직접 입력)" : opt
                        }
                      >
                        {opt}
                      </option>
                    ))}
                  </select>

                  {form.targetCustomer === OTHER_VALUE ? (
                    <div style={{ marginTop: 10 }}>
                      <input
                        value={form.targetCustomerOther}
                        onChange={(e) =>
                          setValue("targetCustomerOther", e.target.value)
                        }
                        placeholder="타깃 고객을 직접 입력하세요 (예: 1인 창업자/개인 크리에이터)"
                      />
                    </div>
                  ) : null}
                </div>
              </div>

              {/* 2) CORE */}
              <div className="card" ref={refCore}>
                <div className="card__head">
                  <h2>2. 브랜드 핵심</h2>
                  <p>이 브랜드가 ‘무엇을 믿는지’를 한 문장으로 정리해요.</p>
                </div>

                <div className="field">
                  <label>
                    브랜드 핵심(정체성/가치) <span className="req">*</span>
                  </label>
                  <textarea
                    value={form.brandCore}
                    onChange={(e) => setValue("brandCore", e.target.value)}
                    placeholder="예) 실행 가능한 전략을 제공해 스타트업 성장을 돕는다"
                    rows={4}
                  />
                </div>
              </div>

              {/* 3) STORY */}
              <div className="card" ref={refStory}>
                <div className="card__head">
                  <h2>3. 스토리 구성</h2>
                  <p>‘시작 계기 → 문제 → 해결’ 흐름으로 적어보세요.</p>
                </div>

                <div className="field">
                  <label>시작 계기(Origin) (선택)</label>
                  <textarea
                    value={form.originStory}
                    onChange={(e) => setValue("originStory", e.target.value)}
                    placeholder="예) 창업 초기, 브랜딩 방향을 잡지 못해 비용/시간이 크게 낭비됨"
                    rows={4}
                  />
                </div>

                <div className="field">
                  <label>고객 문제(Problem) (선택)</label>
                  <textarea
                    value={form.problemStory}
                    onChange={(e) => setValue("problemStory", e.target.value)}
                    placeholder="예) 브랜드 전략이 없어 마케팅 효율이 낮고 전환율이 떨어짐"
                    rows={4}
                  />
                </div>

                <div className="field">
                  <label>해결 방식(Solution) (선택)</label>
                  <textarea
                    value={form.solutionStory}
                    onChange={(e) => setValue("solutionStory", e.target.value)}
                    placeholder="예) 인터뷰 기반 진단 → 전략 추천 → 실행 체크리스트 제공"
                    rows={4}
                  />
                </div>
              </div>

              {/* 4) TONE */}
              <div className="card" ref={refTone}>
                <div className="card__head">
                  <h2>4. 톤/메시지</h2>
                  <p>스토리를 어디에 쓰는지에 따라 말투/구조가 달라져요.</p>
                </div>

                <div className="field">
                  <label>원하는 톤/분위기 (선택)</label>
                  <input
                    value={form.tone}
                    onChange={(e) => setValue("tone", e.target.value)}
                    placeholder="예) 신뢰감, 담백함, 테크, 따뜻함"
                  />
                </div>

                <div className="field">
                  <label>핵심 메시지(3개 정도) (선택)</label>
                  <textarea
                    value={form.keyMessages}
                    onChange={(e) => setValue("keyMessages", e.target.value)}
                    placeholder={
                      "예)\n- 우리는 실행 가능한 전략을 만든다\n- 작은 팀도 바로 적용 가능\n- 비용 대비 효과가 크다"
                    }
                    rows={4}
                  />
                </div>
              </div>

              {/* 5) GOAL */}
              <div className="card" ref={refGoal}>
                <div className="card__head">
                  <h2>5. 목표/근거</h2>
                  <p>스토리의 목적을 정하면 결과물이 더 정확해져요.</p>
                </div>

                <div className="field">
                  <label>
                    스토리 목표(어디에 쓰는가) <span className="req">*</span>
                  </label>
                  <textarea
                    value={form.goal}
                    onChange={(e) => setValue("goal", e.target.value)}
                    placeholder="예) 투자 피치덱/홈페이지 About/서비스 소개 페이지에 사용할 스토리"
                    rows={4}
                  />
                </div>

                <div className="field">
                  <label>근거/증거(성과/수치/사례) (선택)</label>
                  <textarea
                    value={form.proof}
                    onChange={(e) => setValue("proof", e.target.value)}
                    placeholder="예) 테스트 전환율 2%→3.5%, 10개 팀 컨설팅 경험, 수상/인증"
                    rows={4}
                  />
                </div>

                {/* ✅ 기타사항 입력칸(추가 메모) */}
                <div className="field">
                  <label>기타사항 (선택)</label>
                  <textarea
                    value={form.notes}
                    onChange={(e) => setValue("notes", e.target.value)}
                    placeholder="예) 감성적 표현은 줄이고, 깔끔한 톤으로 작성해 주세요 / 참고 브랜드 링크 등"
                    rows={5}
                  />
                </div>
              </div>


              {/* ✅ 결과 영역 (후보 3안 → 1개 선택) */}
              <div ref={refResult} />

              {hasResult ? (
                <div className="card" style={{ marginTop: 14 }}>
                  <div className="card__head">
                    <h2>스토리 후보 3안</h2>
                    <p>
                      후보 1개를 선택하면 로고 컨설팅으로 이동할 수 있어요. (현재는
                      더미 생성)
                    </p>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {candidates.map((c) => {
                      const isSelected = selectedId === c.id;
                      return (
                        <div
                          key={c.id}
                          style={{
                            borderRadius: 16,
                            padding: 14,
                            border: isSelected
                              ? "1px solid rgba(99,102,241,0.45)"
                              : "1px solid rgba(0,0,0,0.08)",
                            boxShadow: isSelected
                              ? "0 12px 30px rgba(99,102,241,0.10)"
                              : "none",
                            background: "rgba(255,255,255,0.6)",
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              gap: 10,
                            }}
                          >
                            <div>
                              <div style={{ fontWeight: 900, fontSize: 15 }}>
                                {c.name}
                              </div>
                              <div style={{ marginTop: 6, opacity: 0.9 }}>
                                {c.oneLiner}
                              </div>
                            </div>

                            <span
                              style={{
                                fontSize: 12,
                                fontWeight: 800,
                                padding: "4px 10px",
                                borderRadius: 999,
                                background: isSelected
                                  ? "rgba(99,102,241,0.12)"
                                  : "rgba(0,0,0,0.04)",
                                border: isSelected
                                  ? "1px solid rgba(99,102,241,0.25)"
                                  : "1px solid rgba(0,0,0,0.06)",
                                color: "rgba(0,0,0,0.75)",
                                height: "fit-content",
                              }}
                            >
                              {isSelected ? "선택됨" : "후보"}
                            </span>
                          </div>

                          <div style={{ marginTop: 10, fontSize: 13, opacity: 0.9 }}>
                            <div>
                              <b>태그라인</b> · {c.tagline}
                            </div>

                            <div style={{ marginTop: 10 }}>
                              <b>요약</b>
                              <ul style={{ marginTop: 6, paddingLeft: 18 }}>
                                {c.about.map((p) => (
                                  <li key={p} style={{ marginBottom: 6 }}>
                                    {p}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div style={{ marginTop: 10 }}>
                              <b>핵심 메시지</b>
                              <ul style={{ marginTop: 6, paddingLeft: 18 }}>
                                {c.keyMessages.map((m) => (
                                  <li key={m} style={{ marginBottom: 6 }}>
                                    {m}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div style={{ marginTop: 10, opacity: 0.85 }}>
                              <b>추천 사용처</b> · {c.useCases.join(", ")}
                            </div>
                          </div>

                          <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
                            <button
                              type="button"
                              className={`btn primary ${isSelected ? "disabled" : ""}`}
                              disabled={isSelected}
                              onClick={() => handleSelectCandidate(c.id)}
                            >
                              {isSelected ? "선택 완료" : "이 방향 선택"}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {canGoNext ? (
                    <div
                      style={{
                        marginTop: 14,
                        display: "flex",
                        justifyContent: "flex-end",
                      }}
                    >
                      <button
                        type="button"
                        className="btn primary"
                        onClick={handleGoNext}
                      >
                        로고 컨설팅으로
                      </button>
                    </div>
                  ) : (
                    <div style={{ marginTop: 12, fontSize: 12, opacity: 0.75 }}>
                      * 후보 1개를 선택하면 이동할 수 있어요.
                    </div>
                  )}
                </div>
              ) : null}


              <div className="bottomBar">
                <button
                  type="button"
                  className="btn ghost"
                  onClick={handleNext}
                >
                  다음 섹션
                </button>
                <button type="button" className="btn" onClick={handleTempSave}>
                  임시저장
                </button>
                <button
                  type="button"
                  className={`btn primary ${canAnalyze ? "" : "disabled"}`}
                  onClick={() => handleGenerateCandidates(hasResult ? "regen" : "generate")}
                  disabled={!canAnalyze || analyzing}
                >
                  {analyzing ? "생성 중..." : hasResult ? "AI 분석 재요청" : "AI 분석 요청"}
                </button>
              </div>
            </section>

            <aside className="diagInterview__right">
              <div className="sideCard">
                {/* ✅ 전체 단계(네이밍→컨셉→스토리→로고) 미니 표시 */}
                <ConsultingFlowMini activeKey="story" />
                <div className="sideCard__titleRow">
                  <h3>진행 상태</h3>
                  <span className="badge">{progress}%</span>
                </div>

                <div
                  className="progressBar"
                  role="progressbar"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={progress}
                >
                  <div
                    className="progressBar__fill"
                    style={{ width: `${progress}%` }}
                  />
                </div>

                <div className="sideMeta">
                  <div className="sideMeta__row">
                    <span className="k">현재 단계</span>
                    <span className="v">{currentSectionLabel}</span>
                  </div>
                  <div className="sideMeta__row">
                    <span className="k">필수 완료</span>
                    <span className="v">
                      {completedRequired}/{requiredKeys.length}
                    </span>
                  </div>
                  <div className="sideMeta__row">
                    <span className="k">마지막 저장</span>
                    <span className="v">{lastSaved}</span>
                  </div>
                </div>

                {saveMsg ? <p className="saveMsg">{saveMsg}</p> : null}

                <div className="divider" />

                <h4 className="sideSubTitle">필수 입력 체크</h4>
                <ul className="checkList">
                  <li className={requiredStatus.companyName ? "ok" : ""}>
                    회사/프로젝트명
                  </li>
                  <li className={requiredStatus.industry ? "ok" : ""}>
                    산업/분야
                    {form.industry === OTHER_VALUE ? " (기타 입력 포함)" : ""}
                  </li>
                  <li className={requiredStatus.stage ? "ok" : ""}>
                    성장 단계
                  </li>
                  <li className={requiredStatus.oneLine ? "ok" : ""}>
                    한 줄 소개
                  </li>
                  <li className={requiredStatus.targetCustomer ? "ok" : ""}>
                    타깃 고객
                    {form.targetCustomer === OTHER_VALUE
                      ? " (기타 입력 포함)"
                      : ""}
                  </li>
                  <li className={requiredStatus.brandCore ? "ok" : ""}>
                    브랜드 핵심
                  </li>
                  <li className={requiredStatus.goal ? "ok" : ""}>
                    스토리 목표
                  </li>
                </ul>

                <div className="divider" />

                <h4 className="sideSubTitle">빠른 이동</h4>
                <div className="jumpGrid">
                  {sections.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      className="jumpBtn"
                      onClick={() => scrollToSection(s.ref)}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  className={`btn primary sideAnalyze ${canAnalyze ? "" : "disabled"}`}
                  onClick={() => handleGenerateCandidates(hasResult ? "regen" : "generate")}
                  disabled={!canAnalyze || analyzing}
                >
                  {analyzing ? "생성 중..." : hasResult ? "AI 분석 재요청" : "AI 분석 요청"}
                </button>

                <button
                  type="button"
                  className="btn ghost"
                  onClick={handleResetAll}
                  style={{ width: "100%", marginTop: 8 }}
                >
                  전체 초기화
                </button>

                {!canAnalyze ? (
                  <p className="hint">
                    * 필수 항목을 모두 입력하면 분석 버튼이 활성화됩니다.
                  </p>
                ) : null}
              </div>
            </aside>
          </div>
        </div>
      </main>

      <SiteFooter onOpenPolicy={setOpenType} />
    </div>
  );
}
